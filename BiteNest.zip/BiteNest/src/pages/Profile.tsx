import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { 
  getUserProgress, 
  getCodeSnippets, 
  Course, 
  Lesson, 
  Progress, 
  CodeSnippet,
  supabase 
} from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';

interface LessonWithCourse extends Lesson {
  course: Course;
}

const Profile = () => {
  const { user, signOut } = useAuth();
  const [completedLessons, setCompletedLessons] = useState<Progress[]>([]);
  const [codeSnippets, setCodeSnippets] = useState<CodeSnippet[]>([]);
  const [lessonDetails, setLessonDetails] = useState<{[key: string]: LessonWithCourse}>({});
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadUserData = async () => {
      if (!user) return;
      
      setLoading(true);
      try {
        // Fetch user progress
        const progress = await getUserProgress(user.id);
        setCompletedLessons(progress);
        
        // Fetch code snippets
        const snippets = await getCodeSnippets(user.id);
        setCodeSnippets(snippets);
        
        // Fetch lesson details for completed lessons
        if (progress.length > 0) {
          const { data } = await supabase
            .from('lessons')
            .select(`
              id,
              course_id,
              title,
              order,
              course:courses(id, title, category)
            `) as unknown as { data: LessonWithCourse[] | null; error: any };
          
          const details: {[key: string]: LessonWithCourse} = {};
          if (data) {
            data.forEach(lesson => {
              details[lesson.id] = lesson;
            });
          }
          
          setLessonDetails(details);
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadUserData();
  }, [user]);
  
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Please log in to view your profile</p>
      </div>
    );
  }
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Loading your profile...</p>
      </div>
    );
  }
  
  // Group lessons by course
  const courseProgress: { [courseId: string]: { course: Course, lessons: Lesson[] }} = {};
  
  completedLessons.forEach(progress => {
    const lesson = lessonDetails[progress.lesson_id];
    if (lesson && lesson.course) {
      const courseId = lesson.course.id;
      
      if (!courseProgress[courseId]) {
        courseProgress[courseId] = {
          course: lesson.course,
          lessons: []
        };
      }
      
      courseProgress[courseId].lessons.push(lesson);
    }
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Your Profile</h1>
          <p className="text-gray-600 mt-1">{user.email}</p>
        </div>
        <Button variant="outline" onClick={signOut}>Sign Out</Button>
      </div>
      
      <Tabs defaultValue="progress">
        <TabsList className="mb-6">
          <TabsTrigger value="progress">Learning Progress</TabsTrigger>
          <TabsTrigger value="snippets">Saved Code Snippets</TabsTrigger>
        </TabsList>
        
        <TabsContent value="progress">
          {Object.keys(courseProgress).length === 0 ? (
            <div className="text-center py-8">
              <p className="text-xl text-gray-500 mb-4">You haven't completed any lessons yet</p>
              <Button asChild>
                <Link to="/courses/coding">Start Learning</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-8">
              {Object.values(courseProgress).map(({ course, lessons }) => (
                <Card key={course.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{course.title}</CardTitle>
                        <Badge variant="outline" className="mt-1">{course.category}</Badge>
                      </div>
                      <Button asChild variant="outline" className="ml-auto">
                        <Link to={`/courses/${course.category}/${course.id}`}>
                          Continue Course
                        </Link>
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <h3 className="font-medium mb-2">Completed Lessons:</h3>
                    <ul className="space-y-2">
                      {lessons.sort((a, b) => a.order - b.order).map(lesson => (
                        <li key={lesson.id} className="flex items-center">
                          <span className="bg-green-100 text-green-600 p-1 rounded-full mr-2">✓</span>
                          <Link 
                            to={`/courses/${course.category}/${course.id}/lessons/${lesson.id}`}
                            className="hover:underline"
                          >
                            {lesson.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="snippets">
          {codeSnippets.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-xl text-gray-500 mb-4">You haven't saved any code snippets yet</p>
              <Button asChild>
                <Link to="/code-generator">Try Code Generator</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {codeSnippets.map(snippet => (
                <Card key={snippet.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{snippet.prompt}</CardTitle>
                    <Badge variant="outline" className="mt-1">{snippet.language}</Badge>
                  </CardHeader>
                  <CardContent>
                    <pre className="bg-gray-800 text-white p-4 rounded-md overflow-x-auto">
                      <code>{snippet.code}</code>
                    </pre>
                    <div className="mt-4 text-right">
                      <p className="text-sm text-gray-500">
                        Saved on {new Date(snippet.created_at || '').toLocaleDateString()}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Profile;
