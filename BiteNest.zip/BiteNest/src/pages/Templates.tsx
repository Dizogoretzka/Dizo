
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getTemplates, type Template } from '@/lib/supabase';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Eye, Code, Download } from 'lucide-react';

const Templates = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const { toast } = useToast();
  const navigate = useNavigate();

  const { data: templates, isLoading, error } = useQuery({
    queryKey: ['templates', selectedCategory],
    queryFn: () => getTemplates(selectedCategory === 'all' ? undefined : selectedCategory),
  });

  const categories = ['all', 'portfolio', 'business', 'blog', 'ecommerce', 'landing'];

  const handleUseTemplate = (template: Template) => {
    // Navigate to code generator with template data
    navigate('/code-generator', { 
      state: { 
        templateCode: template.html_content,
        templatePrompt: `Create a website based on the ${template.name} template: ${template.description}`
      }
    });
  };

  const handlePreviewTemplate = (template: Template) => {
    // Open template in new window for preview
    const newWindow = window.open('', '_blank');
    if (newWindow) {
      newWindow.document.write(template.html_content);
      if (template.css_content) {
        newWindow.document.head.innerHTML += `<style>${template.css_content}</style>`;
      }
      if (template.js_content) {
        newWindow.document.body.innerHTML += `<script>${template.js_content}</script>`;
      }
    }
  };

  const handleDownloadTemplate = (template: Template) => {
    let content = template.html_content;
    
    // Inject CSS if available
    if (template.css_content) {
      content = content.replace('</head>', `<style>${template.css_content}</style></head>`);
    }
    
    // Inject JS if available
    if (template.js_content) {
      content = content.replace('</body>', `<script>${template.js_content}</script></body>`);
    }

    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${template.name.toLowerCase().replace(/\s+/g, '-')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download Started",
      description: `${template.name} template has been downloaded.`,
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-8">Website Templates</h1>
          <p>Loading templates...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-8">Website Templates</h1>
          <p className="text-red-600">Error loading templates. Please try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-4">Website Templates</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Choose from our collection of professionally designed templates and customize them to your needs.
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            onClick={() => setSelectedCategory(category)}
            className="capitalize"
          >
            {category === 'all' ? 'All Templates' : category}
          </Button>
        ))}
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates?.map((template) => (
          <Card key={template.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription className="mt-2">
                    {template.description}
                  </CardDescription>
                </div>
                {template.is_featured && (
                  <Badge variant="secondary">Featured</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Badge variant="outline" className="capitalize">
                  {template.category}
                </Badge>
                
                <div className="flex gap-2">
                  <Button
                    onClick={() => handlePreviewTemplate(template)}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Preview
                  </Button>
                  <Button
                    onClick={() => handleDownloadTemplate(template)}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
                
                <Button
                  onClick={() => handleUseTemplate(template)}
                  className="w-full"
                >
                  <Code className="w-4 h-4 mr-2" />
                  Use Template
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {templates?.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-600">No templates found for the selected category.</p>
        </div>
      )}
    </div>
  );
};

export default Templates;
