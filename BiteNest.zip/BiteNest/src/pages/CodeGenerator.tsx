
import { WebsitePreview } from '@/components/code-generator/WebsitePreview';
import { CodeGeneratorHeader } from '@/components/code-generator/CodeGeneratorHeader';
import { CodeGeneratorSidebar } from '@/components/code-generator/CodeGeneratorSidebar';
import { HowItWorksSection } from '@/components/code-generator/HowItWorksSection';
import { useCodeGenerator } from '@/hooks/useCodeGenerator';

const CodeGenerator = () => {
  const {
    activePrompt,
    customPrompt,
    setCustomPrompt,
    generatedCode,
    isGenerating,
    activeTab,
    setActiveTab,
    handlePromptSelect,
    handleGenerateCode,
    handleDownload,
    handleSaveProject,
  } = useCodeGenerator();

  return (
    <div className="container mx-auto px-4 py-8">
      <CodeGeneratorHeader />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <CodeGeneratorSidebar
          customPrompt={customPrompt}
          onCustomPromptChange={setCustomPrompt}
          onGenerateCode={handleGenerateCode}
          isGenerating={isGenerating}
          activePrompt={activePrompt}
          onPromptSelect={handlePromptSelect}
          onSaveProject={handleSaveProject}
          generatedCode={generatedCode}
        />
        
        <div className="lg:col-span-2">
          <WebsitePreview
            code={generatedCode}
            isGenerating={isGenerating}
            activeTab={activeTab}
            onTabChange={setActiveTab}
            onDownload={handleDownload}
          />
        </div>
      </div>
      
      <HowItWorksSection />
    </div>
  );
};

export default CodeGenerator;
