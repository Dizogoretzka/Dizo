import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getCourses, Course } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

const Courses = () => {
  const { category = 'coding' } = useParams<{ category: string }>();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  
  useEffect(() => {
    const loadCourses = async () => {
      setLoading(true);
      try {
        const data = await getCourses(category);
        setCourses(data);
      } catch (error) {
        console.error('Error loading courses:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadCourses();
  }, [category]);
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Loading courses...</p>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">
          {category === 'coding' ? 'Coding Courses' : 'AI Education'}
        </h1>
        <div className="flex space-x-2">
          <Button
            variant={category === 'coding' ? 'default' : 'outline'}
            asChild
          >
            <Link to="/courses/coding">Coding</Link>
          </Button>
          <Button
            variant={category === 'ai' ? 'default' : 'outline'}
            asChild
          >
            <Link to="/courses/ai">AI</Link>
          </Button>
        </div>
      </div>
      
      {courses.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-xl text-gray-500 mb-4">No courses available in this category yet.</p>
          {!user && (
            <Button asChild>
              <Link to="/signup">Sign Up to Get Notified</Link>
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Card key={course.id} className="course-card">
              <CardHeader className="pb-3">
                <CardTitle>{course.title}</CardTitle>
                <CardDescription>{course.description}</CardDescription>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="h-40 bg-aisod-light-purple/10 rounded-md flex items-center justify-center mb-3">
                  {course.image_url ? (
                    <img
                      src={course.image_url}
                      alt={course.title}
                      className="h-full w-full object-cover rounded-md"
                    />
                  ) : (
                    <span className="text-5xl">{course.title.substring(0, 2).toUpperCase()}</span>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" asChild>
                  <Link to={`/courses/${course.category}/${course.id}`}>View Course</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
      
      {courses.length > 0 && !user && (
        <div className="mt-12 p-6 bg-aisod-light-purple/10 rounded-lg text-center">
          <h2 className="text-2xl font-bold mb-2">Track Your Progress</h2>
          <p className="text-lg mb-4">Sign up to track your learning progress and save your work.</p>
          <Button asChild>
            <Link to="/signup">Create Account</Link>
          </Button>
        </div>
      )}
    </div>
  );
};

export default Courses;
