
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles, Code, Download, Eye, Palette, Zap, Shield } from "lucide-react";

const Home = () => {
  const features = [
    {
      icon: <Sparkles className="h-8 w-8 text-blue-500" />,
      title: "AI-Powered Generation",
      description: "Describe your website in plain English and watch our AI create it instantly"
    },
    {
      icon: <Palette className="h-8 w-8 text-purple-500" />,
      title: "Professional Templates",
      description: "Choose from our curated collection of responsive, modern templates"
    },
    {
      icon: <Code className="h-8 w-8 text-green-500" />,
      title: "Clean Code Output",
      description: "Get production-ready HTML, CSS, and JavaScript that you can use anywhere"
    },
    {
      icon: <Zap className="h-8 w-8 text-yellow-500" />,
      title: "Instant Preview",
      description: "See your website come to life in real-time with our live preview feature"
    },
    {
      icon: <Download className="h-8 w-8 text-indigo-500" />,
      title: "Export Ready",
      description: "Download your website as a complete HTML file ready for hosting"
    },
    {
      icon: <Shield className="h-8 w-8 text-red-500" />,
      title: "Save & Manage",
      description: "Keep your projects organized and accessible from anywhere"
    }
  ];

  const useCases = [
    {
      title: "Portfolio Websites",
      description: "Showcase your work with stunning portfolio designs",
      color: "bg-blue-500"
    },
    {
      title: "Business Landing Pages",
      description: "Convert visitors with professional landing pages",
      color: "bg-green-500"
    },
    {
      title: "Personal Blogs",
      description: "Share your thoughts with beautiful blog layouts",
      color: "bg-purple-500"
    },
    {
      title: "Product Showcases",
      description: "Highlight your products with elegant presentations",
      color: "bg-orange-500"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20 px-4">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4">
            ✨ Powered by Advanced AI
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            BiteNest
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Create stunning, responsive websites in seconds using natural language. 
            No coding required – just describe your vision and watch it come to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="text-lg px-8 py-6">
              <Link to="/code-generator">
                Start Creating <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6">
              <Link to="/templates">
                Browse Templates <Eye className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Why Choose BiteNest?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience the future of web development with our AI-powered platform
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow border-0 shadow-md">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    {feature.icon}
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Perfect for Every Need</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              From personal projects to business websites, BiteNest has you covered
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {useCases.map((useCase, index) => (
              <Card key={index} className="hover:shadow-lg transition-all hover:-translate-y-1">
                <CardHeader>
                  <div className={`w-12 h-12 ${useCase.color} rounded-lg flex items-center justify-center mb-4`}>
                    <Code className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle className="text-lg">{useCase.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{useCase.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Creating your perfect website is as easy as 1-2-3
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                1
              </div>
              <h3 className="text-2xl font-semibold mb-4">Describe Your Vision</h3>
              <p className="text-gray-600 text-lg">
                Tell our AI what kind of website you want in plain English. Be as detailed or as simple as you like.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                2
              </div>
              <h3 className="text-2xl font-semibold mb-4">AI Creates Your Site</h3>
              <p className="text-gray-600 text-lg">
                Our advanced AI generates a complete, responsive website with modern design and clean code.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                3
              </div>
              <h3 className="text-2xl font-semibold mb-4">Download & Deploy</h3>
              <p className="text-gray-600 text-lg">
                Preview your website, make any final tweaks, then download and deploy it anywhere you want.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Build Your Dream Website?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of creators who are already using BiteNest to bring their ideas to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary" className="text-lg px-8 py-6">
              <Link to="/code-generator">
                Get Started Free <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent text-white border-white hover:bg-white hover:text-blue-600">
              <Link to="/templates">
                Explore Templates
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
