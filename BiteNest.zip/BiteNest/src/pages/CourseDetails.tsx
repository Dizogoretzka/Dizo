import { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { 
  getCourse, 
  getLessons, 
  getUserProgress, 
  Course, 
  Lesson, 
  Progress, 
  supabase 
} from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";

const CourseDetails = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const [course, setCourse] = useState<Course | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [userProgress, setUserProgress] = useState<Progress[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const loadCourseData = async () => {
      if (!courseId) return;

      setLoading(true);
      try {
        // Fetch course details
        const { data: courseData, error: courseError } = await supabase
          .from("courses")
          .select("*")
          .eq("id", courseId)
          .single() as unknown as { data: Course | null; error: any };

        if (courseError) throw courseError;
        setCourse(courseData);

        // Fetch lessons
        const lessonData = await getLessons(courseId);
        setLessons(lessonData);

        // Fetch user progress if logged in
        if (user) {
          const progressData = await getUserProgress(user.id);
          setUserProgress(progressData);
        }
      } catch (error) {
        console.error("Error loading course data:", error);
        // Redirect to courses page if course not found
        navigate("/courses/coding");
      } finally {
        setLoading(false);
      }
    };

    loadCourseData();
  }, [courseId, user, navigate]);

  const isLessonCompleted = (lessonId: string): boolean => {
    return userProgress.some(
      (progress) => progress.lesson_id === lessonId && progress.completed
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Loading course...</p>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Course not found</p>
        <Button asChild className="mt-4">
          <Link to="/courses/coding">Back to Courses</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <Link
            to={`/courses/${course.category}`}
            className="text-sm text-aisod-purple hover:underline mb-2 inline-block"
          >
            ← Back to {course.category === "coding" ? "Coding" : "AI"} Courses
          </Link>
          <h1 className="text-3xl font-bold">{course.title}</h1>
          <p className="text-gray-600 mt-2">{course.description}</p>
        </div>
        
        {user && lessons.length > 0 && (
          <Button asChild>
            <Link to={`/courses/${course.category}/${course.id}/lessons/${lessons[0].id}`}>
              {userProgress.length > 0 ? "Continue Learning" : "Start Course"}
            </Link>
          </Button>
        )}
      </div>

      {lessons.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-xl text-gray-500">
            No lessons available for this course yet.
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {lessons.map((lesson, index) => (
            <Card key={lesson.id} className="transition-all hover:shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="flex justify-between items-center">
                  <span>
                    Lesson {index + 1}: {lesson.title}
                  </span>
                  {user && isLessonCompleted(lesson.id) && (
                    <span className="text-green-500 text-sm font-normal bg-green-100 px-2 py-1 rounded-full">
                      Completed
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button asChild>
                  <Link to={`/courses/${course.category}/${course.id}/lessons/${lesson.id}`}>
                    {user && isLessonCompleted(lesson.id) ? "Review Lesson" : "Start Lesson"}
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* CTA for non-authenticated users */}
      {!user && (
        <div className="mt-8 p-6 bg-aisod-light-purple/10 rounded-lg text-center">
          <h2 className="text-2xl font-bold mb-2">Track Your Progress</h2>
          <p className="text-lg mb-4">
            Sign up to track your progress and unlock all course features.
          </p>
          <Button asChild>
            <Link to="/signup">Create Account</Link>
          </Button>
        </div>
      )}
    </div>
  );
};

export default CourseDetails;
