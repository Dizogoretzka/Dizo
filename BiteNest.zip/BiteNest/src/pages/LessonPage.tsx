import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { getLesson, getLessons, markLessonAsCompleted, Lesson } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { LessonSidebar } from '@/components/lesson/LessonSidebar';
import { MarkdownRenderer } from '@/components/lesson/MarkdownRenderer';
import { LessonNavigation } from '@/components/lesson/LessonNavigation';

const LessonPage = () => {
  const { courseId, lessonId } = useParams<{ courseId: string; lessonId: string }>();
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [nextLesson, setNextLesson] = useState<Lesson | null>(null);
  const [prevLesson, setPrevLesson] = useState<Lesson | null>(null);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const loadLessonData = async () => {
      if (!courseId || !lessonId) return;
      setLoading(true);
      try {
        const allLessons = await getLessons(courseId);
        setLessons(allLessons);
        
        const currentLesson = await getLesson(lessonId);
        if (!currentLesson) {
          throw new Error('Lesson not found');
        }
        setLesson(currentLesson);
        
        const currentIndex = allLessons.findIndex(l => l.id === lessonId);
        setPrevLesson(currentIndex > 0 ? allLessons[currentIndex - 1] : null);
        setNextLesson(currentIndex < allLessons.length - 1 ? allLessons[currentIndex + 1] : null);
      } catch (error) {
        console.error('Error loading lesson:', error);
        navigate(`/courses/${courseId}`);
      } finally {
        setLoading(false);
      }
    };
    
    loadLessonData();
  }, [courseId, lessonId, navigate]);

  const handleMarkAsComplete = async () => {
    if (!user || !lessonId) {
      toast({
        title: "Authentication Required",
        description: "Please login to track your progress",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await markLessonAsCompleted(user.id, lessonId);
      toast({
        title: "Progress Saved",
        description: "Lesson marked as completed"
      });
      
      if (nextLesson) {
        navigate(`/courses/${courseId}/lessons/${nextLesson.id}`);
      } else {
        navigate(`/courses/${courseId}`);
      }
    } catch (error) {
      console.error('Error marking lesson as completed:', error);
      toast({
        title: "Error",
        description: "Failed to update progress. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Loading lesson...</p>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Lesson not found</p>
        <Button asChild className="mt-4">
          <Link to={`/courses/${courseId}`}>Back to Course</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-6">
        <LessonSidebar
          lessons={lessons}
          currentLessonId={lessonId}
          courseId={courseId}
        />
        
        <main className="flex-1">
          <div className="md:hidden mb-4">
            <Link
              to={`/courses/${courseId}`}
              className="text-sm text-aisod-purple hover:underline mb-4 inline-block"
            >
              ← Back to Course
            </Link>
          </div>
          
          <h1 className="text-3xl font-bold mb-6">{lesson.title}</h1>
          
          <MarkdownRenderer content={lesson.content} />
          
          <LessonNavigation
            prevLesson={prevLesson}
            nextLesson={nextLesson}
            courseId={courseId}
            onComplete={handleMarkAsComplete}
            isAuthenticated={!!user}
          />
          
          {!user && (
            <div className="mt-8 p-6 bg-aisod-light-purple/10 rounded-lg text-center">
              <h2 className="text-xl font-bold mb-2">Track Your Progress</h2>
              <p className="mb-4">
                Sign up to mark lessons as completed and track your learning journey.
              </p>
              <Button asChild>
                <Link to="/signup">Create Account</Link>
              </Button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default LessonPage;
