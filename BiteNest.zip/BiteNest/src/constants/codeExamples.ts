// Code examples for each prompt
export const CODE_EXAMPLES = {
  'Create a React button component with hover effects using Tailwind CSS': `import React from 'react';

type ButtonProps = {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  disabled?: boolean;
};

const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  disabled = false
}: ButtonProps) => {
  // Tailwind classes based on variant and size
  const baseClasses = "font-medium rounded transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2";
  
  const variantClasses = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500",
    secondary: "bg-gray-200 text-gray-900 hover:bg-gray-300 focus:ring-gray-500",
    outline: "border border-gray-300 text-gray-700 hover:bg-gray-50 focus:ring-gray-500"
  };
  
  const sizeClasses = {
    sm: "px-2 py-1 text-sm",
    md: "px-4 py-2",
    lg: "px-6 py-3 text-lg"
  };
  
  const classes = \`\${baseClasses} \${variantClasses[variant]} \${sizeClasses[size]}\`;
  
  return (
    <button
      className={classes}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
};

export default Button;`,

  'Create functions that demonstrate map, filter, and reduce operations on arrays': `// Sample array of data
const people = [
  { id: 1, name: "Alice", age: 25, job: "Engineer" },
  { id: 2, name: "Bob", age: 32, job: "Designer" },
  { id: 3, name: "Charlie", age: 19, job: "Student" },
  { id: 4, name: "Diana", age: 28, job: "Engineer" },
  { id: 5, name: "Evan", age: 45, job: "Manager" },
];

// MAP: Transform array data
// Get an array of just the names
const getNames = (people) => {
  return people.map(person => person.name);
};

// Transform to a more detailed format
const getDetailedInfo = (people) => {
  return people.map(person => ({
    ...person,
    description: \`\${person.name} is \${person.age} years old and works as a \${person.job}\`,
    ageNextYear: person.age + 1
  }));
};

// FILTER: Get subset of array based on condition
// Get only people who are 25 or older
const getAdults = (people) => {
  return people.filter(person => person.age >= 25);
};

// Get engineers
const getByProfession = (people, profession) => {
  return people.filter(person => person.job.toLowerCase() === profession.toLowerCase());
};

// REDUCE: Aggregate array data
// Calculate the sum of everyone's age
const getTotalAge = (people) => {
  return people.reduce((total, person) => total + person.age, 0);
};

// Group people by profession
const groupByProfession = (people) => {
  return people.reduce((groups, person) => {
    // Get the job title
    const job = person.job;
    
    // If this job title isn't a key in our object yet, create it
    if (!groups[job]) {
      groups[job] = [];
    }
    
    // Add this person to the appropriate job group
    groups[job].push(person);
    
    return groups;
  }, {});
};

// CHAINING: Combining operations
// Get the average age of engineers
const getAverageAgeByProfession = (people, profession) => {
  const professionGroup = people
    .filter(person => person.job.toLowerCase() === profession.toLowerCase());
  
  if (professionGroup.length === 0) return 0;
  
  const totalAge = professionGroup
    .reduce((sum, person) => sum + person.age, 0);
    
  return totalAge / professionGroup.length;
};

// Examples
console.log("Names:", getNames(people));
console.log("Adults:", getAdults(people));
console.log("Engineers:", getByProfession(people, "Engineer"));
console.log("Total Age:", getTotalAge(people));
console.log("Grouped by Profession:", groupByProfession(people));
console.log("Average Engineer Age:", getAverageAgeByProfession(people, "Engineer"));`,

  'Write CSS for a responsive grid layout with 3 columns on desktop and 1 column on mobile': `.grid-container {
  display: grid;
  grid-template-columns: 1fr;  /* Single column by default (mobile) */
  gap: 1rem;
  padding: 1rem;
  max-width: 1200px;
  margin: 0 auto;
}

/* Card styling */
.card {
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 1.5rem;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.card h2 {
  margin-top: 0;
  color: #333;
  font-size: 1.25rem;
}

.card p {
  color: #666;
  line-height: 1.5;
}

/* Tablet breakpoint */
@media (min-width: 768px) {
  .grid-container {
    grid-template-columns: repeat(2, 1fr);  /* 2 columns for tablets */
  }
}

/* Desktop breakpoint */
@media (min-width: 1024px) {
  .grid-container {
    grid-template-columns: repeat(3, 1fr);  /* 3 columns for desktop */
  }
}

/* Usage Example in HTML:
<div class="grid-container">
  <div class="card">
    <h2>Card Title 1</h2>
    <p>Card description goes here...</p>
  </div>
  <div class="card">
    <h2>Card Title 2</h2>
    <p>Card description goes here...</p>
  </div>
  <div class="card">
    <h2>Card Title 3</h2>
    <p>Card description goes here...</p>
  </div>
  <!-- More cards... -->
</div>
*/`,

  'Create a custom React hook for fetching data from an API with loading and error states': `import { useState, useEffect } from 'react';

/**
 * A custom hook for fetching data from an API with loading and error states
 * 
 * @param url The URL to fetch data from
 * @param options Optional fetch options
 * @returns An object containing the data, loading state, error state, and a refetch function
 */
const useFetch = <T>(url: string, options?: RequestInit) => {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const [refreshCount, setRefreshCount] = useState<number>(0);

  // Function to manually trigger a refetch
  const refetch = () => setRefreshCount(count => count + 1);

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;
    
    const fetchData = async () => {
      setLoading(true);
      
      try {
        const response = await fetch(url, {
          ...options,
          signal,
        });
        
        // Handle non-2xx responses
        if (!response.ok) {
          throw new Error(\`HTTP error! Status: \${response.status}\`);
        }
        
        const result = await response.json();
        setData(result as T);
        setError(null);
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          setError(error as Error);
          setData(null);
        }
      } finally {
        // Only set loading to false if the request wasn't aborted
        if (!signal.aborted) {
          setLoading(false);
        }
      }
    };
    
    fetchData();
    
    // Cleanup function to abort fetch on unmount or dependency change
    return () => {
      controller.abort();
    };
  }, [url, refreshCount]); // Re-run when URL changes or refetch is called
  
  return { data, loading, error, refetch };
};

export default useFetch;

// Usage Example:
/*
import useFetch from './useFetch';

interface Post {
  id: number;
  title: string;
  body: string;
}

function PostComponent() {
  const { data, loading, error, refetch } = useFetch<Post[]>('https://jsonplaceholder.typicode.com/posts');
  
  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;
  
  return (
    <div>
      <button onClick={refetch}>Refresh</button>
      <h1>Posts</h1>
      <ul>
        {data?.map(post => (
          <li key={post.id}>
            <h2>{post.title}</h2>
            <p>{post.body}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
*/`
};
