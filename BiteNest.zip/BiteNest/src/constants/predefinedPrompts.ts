
export const PREDEFINED_PROMPTS = [
  {
    title: 'Restaurant Landing Page',
    prompt: 'Create a modern restaurant landing page with a hero section featuring a background image, navigation menu, about section, menu highlights with food images, customer reviews, and contact information with location map placeholder. Use warm colors and elegant typography.',
    language: 'html'
  },
  {
    title: 'Personal Portfolio Website',
    prompt: 'Build a personal portfolio website for a web developer with a hero section, about me section, skills showcase with progress bars, project gallery with hover effects, testimonials, and contact form. Use a modern design with dark/light theme.',
    language: 'html'
  },
  {
    title: 'SaaS Product Landing Page',
    prompt: 'Create a SaaS landing page with a compelling hero section, feature highlights with icons, pricing table with 3 tiers, testimonials carousel, FAQ section, and call-to-action buttons. Use gradient backgrounds and modern UI elements.',
    language: 'html'
  },
  {
    title: 'Blog Website',
    prompt: 'Design a modern blog website with header navigation, featured article hero section, blog post grid with thumbnails and excerpts, sidebar with categories and recent posts, search functionality, and footer with social links.',
    language: 'html'
  },
  {
    title: 'E-commerce Product Page',
    prompt: 'Create a product page for an online store with product image gallery, product details, add to cart functionality, customer reviews section, related products, and trust badges. Include responsive design and shopping cart icon.',
    language: 'html'
  },
  {
    title: 'Business Agency Website',
    prompt: 'Build a professional agency website with hero banner, services section with cards, team members grid, client logos, case studies, testimonials, and contact form. Use corporate colors and clean design.',
    language: 'html'
  },
  {
    title: 'Real Estate Website',
    prompt: 'Create a real estate website with property search filters, featured listings with images, agent profiles, neighborhood information, mortgage calculator, and contact forms. Use professional blue and white color scheme.',
    language: 'html'
  },
  {
    title: 'Fitness Gym Website',
    prompt: 'Design a fitness gym website with hero video section, class schedules, trainer profiles, membership pricing, facility gallery, success stories, and online booking system. Use energetic colors and bold typography.',
    language: 'html'
  }
];
