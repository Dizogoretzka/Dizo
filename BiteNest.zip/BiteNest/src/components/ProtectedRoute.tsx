
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface ProtectedRouteProps {
  redirectTo?: string;
}

const ProtectedRoute = ({ redirectTo = "/login" }: ProtectedRouteProps) => {
  const { user, loading } = useAuth();

  // While checking authentication status, show nothing
  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }

  // If not authenticated, redirect to login
  if (!user) {
    return <Navigate to={redirectTo} />;
  }

  // If authenticated, render the outlet
  return <Outlet />;
};

export default ProtectedRoute;
