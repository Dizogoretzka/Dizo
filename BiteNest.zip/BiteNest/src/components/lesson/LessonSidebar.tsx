
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Lesson } from "@/lib/supabase";

interface LessonSidebarProps {
  lessons: Lesson[];
  currentLessonId: string;
  courseId: string;
}

export const LessonSidebar = ({ lessons, currentLessonId, courseId }: LessonSidebarProps) => {
  return (
    <aside className="hidden md:block w-64 shrink-0">
      <div className="sticky top-20 bg-white p-4 rounded-lg border">
        <h3 className="font-bold text-lg mb-4">Lessons</h3>
        <ul className="space-y-2">
          {lessons.map((lesson, index) => (
            <li key={lesson.id}>
              <Link
                to={`/courses/${courseId}/lessons/${lesson.id}`}
                className={`block p-2 rounded ${
                  lesson.id === currentLessonId ? 'bg-aisod-purple text-white' : 'hover:bg-gray-100'
                }`}
              >
                {index + 1}. {lesson.title}
              </Link>
            </li>
          ))}
        </ul>
        <Separator className="my-4" />
        <Button asChild variant="outline" className="w-full">
          <Link to={`/courses/${courseId}`}>Back to Course</Link>
        </Button>
      </div>
    </aside>
  );
};
