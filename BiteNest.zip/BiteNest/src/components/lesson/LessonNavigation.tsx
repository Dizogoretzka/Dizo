
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Lesson } from "@/lib/supabase";

interface LessonNavigationProps {
  prevLesson: Lesson | null;
  nextLesson: Lesson | null;
  courseId: string;
  onComplete: () => void;
  isAuthenticated: boolean;
}

export const LessonNavigation = ({
  prevLesson,
  nextLesson,
  courseId,
  onComplete,
  isAuthenticated,
}: LessonNavigationProps) => {
  return (
    <div className="flex flex-wrap gap-4 justify-between mt-8 pt-6 border-t">
      <div>
        {prevLesson && (
          <Button variant="outline" asChild>
            <Link to={`/courses/${courseId}/lessons/${prevLesson.id}`}>
              ← Previous Lesson
            </Link>
          </Button>
        )}
      </div>
      
      <div className="flex gap-2">
        {isAuthenticated && (
          <Button onClick={onComplete}>
            {nextLesson ? "Complete & Continue" : "Mark as Complete"}
          </Button>
        )}
        
        {nextLesson && (
          <Button asChild variant={isAuthenticated ? "outline" : "default"}>
            <Link to={`/courses/${courseId}/lessons/${nextLesson.id}`}>
              Next Lesson →
            </Link>
          </Button>
        )}
        
        {!nextLesson && (
          <Button asChild variant="outline">
            <Link to={`/courses/${courseId}`}>
              Back to Course
            </Link>
          </Button>
        )}
      </div>
    </div>
  );
};
