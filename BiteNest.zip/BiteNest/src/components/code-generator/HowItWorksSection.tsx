
export const HowItWorksSection = () => {
  return (
    <div className="mt-16 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-8">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-4">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-8 mt-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">1</div>
            <h3 className="text-xl font-semibold mb-2">Choose or Describe</h3>
            <p className="text-gray-600">Select a template or describe your ideal website in plain English</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-purple-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">2</div>
            <h3 className="text-xl font-semibold mb-2">AI Generates</h3>
            <p className="text-gray-600">Our AI creates a complete, responsive website with modern design</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">3</div>
            <h3 className="text-xl font-semibold mb-2">Download & Use</h3>
            <p className="text-gray-600">Preview, download, and use your website immediately</p>
          </div>
        </div>
      </div>
    </div>
  );
};
