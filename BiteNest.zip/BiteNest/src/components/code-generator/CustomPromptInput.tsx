
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Sparkles } from 'lucide-react';

interface CustomPromptInputProps {
  value: string;
  onChange: (value: string) => void;
  onGenerate: () => void;
  isGenerating: boolean;
}

export const CustomPromptInput = ({ value, onChange, onGenerate, isGenerating }: CustomPromptInputProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Describe Your Website</CardTitle>
        <CardDescription>
          Tell AI what kind of website you want to create
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="E.g., Create a modern coffee shop website with online ordering, location info, and customer reviews"
          className="min-h-[120px] resize-none"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
        <Button 
          className="w-full"
          onClick={onGenerate}
          disabled={isGenerating || !value.trim()}
        >
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Website...
            </>
          ) : (
            <>
              <Sparkles className="mr-2 h-4 w-4" />
              Generate Website
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
};
