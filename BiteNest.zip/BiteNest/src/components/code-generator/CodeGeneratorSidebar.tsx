
import { CustomPromptInput } from './CustomPromptInput';
import { PredefinedPrompts } from './PredefinedPrompts';
import { SaveProjectButton } from './SaveProjectButton';
import { PREDEFINED_PROMPTS } from '@/constants/predefinedPrompts';

interface CodeGeneratorSidebarProps {
  customPrompt: string;
  onCustomPromptChange: (value: string) => void;
  onGenerateCode: () => void;
  isGenerating: boolean;
  activePrompt: string;
  onPromptSelect: (prompt: string, language: string) => void;
  onSaveProject: (projectName: string) => void;
  generatedCode: string;
}

export const CodeGeneratorSidebar = ({
  customPrompt,
  onCustomPromptChange,
  onGenerateCode,
  isGenerating,
  activePrompt,
  onPromptSelect,
  onSaveProject,
  generatedCode,
}: CodeGeneratorSidebarProps) => {
  return (
    <div className="lg:col-span-1 space-y-6">
      <CustomPromptInput
        value={customPrompt}
        onChange={onCustomPromptChange}
        onGenerate={onGenerateCode}
        isGenerating={isGenerating}
      />

      <PredefinedPrompts
        prompts={PREDEFINED_PROMPTS}
        activePrompt={activePrompt}
        customPrompt={customPrompt}
        onSelect={onPromptSelect}
      />
      
      <SaveProjectButton
        onSave={onSaveProject}
        disabled={!activePrompt || !generatedCode.trim()}
      />
    </div>
  );
};
