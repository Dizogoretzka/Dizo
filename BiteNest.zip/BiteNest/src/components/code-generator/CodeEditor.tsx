
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Editor from '@monaco-editor/react';
import { Loader2 } from 'lucide-react';
import { useRef } from 'react';

interface CodeEditorProps {
  code: string;
  language: string;
  output: string;
  isGenerating: boolean;
  isRunning: boolean;
  activeTab: string;
  onCodeChange: (value: string | undefined) => void;
  onTabChange: (value: string) => void;
  onRunCode: () => void;
}

export const CodeEditor = ({ 
  code, 
  language, 
  output, 
  isGenerating, 
  isRunning, 
  activeTab,
  onCodeChange,
  onTabChange,
  onRunCode
}: CodeEditorProps) => {
  const outputRef = useRef<HTMLDivElement>(null);

  return (
    <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
      <TabsList className="grid w-full grid-cols-2 mb-4">
        <TabsTrigger value="editor">Code Editor</TabsTrigger>
        <TabsTrigger value="output" disabled={language !== 'javascript'}>Output</TabsTrigger>
      </TabsList>
      
      <TabsContent value="editor" className="border rounded-md p-0 overflow-hidden">
        <div className="bg-gray-800 text-white px-4 py-2 text-sm flex justify-between items-center">
          <div>
            <span className="font-mono">{language}</span>
          </div>
          {language === 'javascript' && (
            <Button
              size="sm"
              variant="outline"
              className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600 hover:text-white"
              onClick={onRunCode}
              disabled={isRunning || !code.trim()}
            >
              {isRunning ? 'Running...' : 'Run Code'}
            </Button>
          )}
        </div>
        <div className="h-[500px]">
          {isGenerating ? (
            <div className="flex items-center justify-center h-full bg-gray-900">
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
                <p className="text-gray-300">Generating your code...</p>
                <p className="text-gray-500 text-sm mt-2">This might take a few seconds</p>
              </div>
            </div>
          ) : (
            <Editor
              height="100%"
              language={language}
              value={code}
              onChange={onCodeChange}
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                wordWrap: 'on',
              }}
            />
          )}
        </div>
      </TabsContent>
      
      <TabsContent value="output" className="border rounded-md overflow-hidden">
        <div className="bg-gray-800 text-white px-4 py-2 text-sm">
          <span className="font-mono">Console Output</span>
        </div>
        <div 
          ref={outputRef}
          className="bg-black text-green-400 p-4 font-mono text-sm whitespace-pre-line h-[500px] overflow-y-auto"
        >
          {output || (language === 'javascript' ? 'Run the code to see output here...' : 'Output is only available for JavaScript code')}
        </div>
      </TabsContent>
    </Tabs>
  );
};
