
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download, ExternalLink, Code } from 'lucide-react';
import { useRef } from 'react';

interface WebsitePreviewProps {
  code: string;
  isGenerating: boolean;
  activeTab: string;
  onTabChange: (value: string) => void;
  onDownload: () => void;
}

export const WebsitePreview = ({ 
  code, 
  isGenerating, 
  activeTab,
  onTabChange,
  onDownload
}: WebsitePreviewProps) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const openInNewTab = () => {
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 100);
  };

  return (
    <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
      <TabsList className="grid w-full grid-cols-2 mb-4">
        <TabsTrigger value="preview">Live Preview</TabsTrigger>
        <TabsTrigger value="code">HTML Code</TabsTrigger>
      </TabsList>
      
      <TabsContent value="preview" className="border rounded-md overflow-hidden">
        <div className="bg-gray-800 text-white px-4 py-2 text-sm flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="ml-4 font-mono text-xs">Website Preview</span>
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600 hover:text-white"
              onClick={openInNewTab}
              disabled={!code.trim()}
            >
              <ExternalLink className="w-3 h-3 mr-1" />
              Open
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600 hover:text-white"
              onClick={onDownload}
              disabled={!code.trim()}
            >
              <Download className="w-3 h-3 mr-1" />
              Download
            </Button>
          </div>
        </div>
        <div className="h-[600px] bg-white">
          {isGenerating ? (
            <div className="flex items-center justify-center h-full bg-gray-50">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-gray-600">Generating your website...</p>
                <p className="text-gray-500 text-sm mt-2">This may take a few seconds</p>
              </div>
            </div>
          ) : code ? (
            <iframe
              ref={iframeRef}
              srcDoc={code}
              className="w-full h-full border-0"
              title="Website Preview"
              sandbox="allow-scripts allow-same-origin"
            />
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <Code className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p>Your generated website will appear here</p>
                <p className="text-sm mt-2">Choose a template or enter a custom prompt to get started</p>
              </div>
            </div>
          )}
        </div>
      </TabsContent>
      
      <TabsContent value="code" className="border rounded-md overflow-hidden">
        <div className="bg-gray-800 text-white px-4 py-2 text-sm flex justify-between items-center">
          <span className="font-mono">HTML Source Code</span>
          <Button
            size="sm"
            variant="outline"
            className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600 hover:text-white"
            onClick={() => navigator.clipboard.writeText(code)}
            disabled={!code.trim()}
          >
            Copy Code
          </Button>
        </div>
        <div className="h-[600px] bg-gray-900 text-green-400 p-4 font-mono text-sm overflow-auto whitespace-pre-wrap">
          {code || 'Generated HTML code will appear here...'}
        </div>
      </TabsContent>
    </Tabs>
  );
};
