
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export type PromptItem = {
  title: string;
  prompt: string;
  language: string;
};

interface PredefinedPromptsProps {
  prompts: PromptItem[];
  activePrompt: string;
  customPrompt: string;
  onSelect: (prompt: string, language: string) => void;
}

export const PredefinedPrompts = ({ prompts, activePrompt, customPrompt, onSelect }: PredefinedPromptsProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Website Templates</CardTitle>
        <CardDescription>
          Choose from popular website types
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {prompts.map((item, index) => (
            <div 
              key={index}
              className={`p-4 rounded-lg cursor-pointer border-2 transition-all hover:shadow-md ${
                activePrompt === item.prompt && !customPrompt 
                  ? 'border-primary bg-primary/5 shadow-md' 
                  : 'border-gray-200 hover:border-primary/30'
              }`}
              onClick={() => onSelect(item.prompt, item.language)}
            >
              <h3 className="font-semibold text-sm mb-1">{item.title}</h3>
              <p className="text-xs text-gray-600 line-clamp-2">{item.prompt}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
