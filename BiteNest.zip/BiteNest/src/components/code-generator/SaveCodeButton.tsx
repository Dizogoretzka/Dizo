
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface SaveCodeButtonProps {
  onSave: () => void;
  disabled: boolean;
}

export const SaveCodeButton = ({ onSave, disabled }: SaveCodeButtonProps) => {
  const { user } = useAuth();

  if (user) {
    return (
      <Button 
        variant="outline" 
        className="w-full"
        onClick={onSave}
        disabled={disabled}
      >
        Save Website to My Profile
      </Button>
    );
  }

  return (
    <div className="p-4 bg-gray-50 rounded-md">
      <p className="text-sm text-gray-600 mb-2">
        Sign in to save your generated websites
      </p>
      <Button asChild variant="outline" size="sm" className="mr-2">
        <Link to="/login">Sign In</Link>
      </Button>
      <Button asChild size="sm">
        <Link to="/signup">Create Account</Link>
      </Button>
    </div>
  );
};
