
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface SaveProjectButtonProps {
  onSave: (projectName: string) => void;
  disabled: boolean;
}

export const SaveProjectButton = ({ onSave, disabled }: SaveProjectButtonProps) => {
  const { user } = useAuth();
  const [projectName, setProjectName] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleSave = () => {
    if (projectName.trim()) {
      onSave(projectName.trim());
      setProjectName('');
      setIsOpen(false);
    }
  };

  if (user) {
    return (
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            variant="outline" 
            className="w-full"
            disabled={disabled}
          >
            Save Project
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Project</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label htmlFor="projectName" className="text-sm font-medium">
                Project Name
              </label>
              <Input
                id="projectName"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                placeholder="Enter project name..."
                className="mt-1"
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleSave}
                disabled={!projectName.trim()}
                className="flex-1"
              >
                Save Project
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setIsOpen(false)}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <div className="p-4 bg-gray-50 rounded-md">
      <p className="text-sm text-gray-600 mb-2">
        Sign in to save your generated websites
      </p>
      <Button asChild variant="outline" size="sm" className="mr-2">
        <Link to="/login">Sign In</Link>
      </Button>
      <Button asChild size="sm">
        <Link to="/signup">Create Account</Link>
      </Button>
    </div>
  );
};
