
export const CodeGeneratorHeader = () => {
  return (
    <div className="text-center mb-8">
      <h1 className="text-4xl font-bold mb-4">AI Website Generator</h1>
      <p className="text-xl text-gray-600 max-w-2xl mx-auto">
        Create beautiful, responsive websites in seconds using AI. 
        Choose from templates or describe your vision in your own words.
      </p>
    </div>
  );
};
