
import { useState } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { saveProject, supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

export const useCodeGenerator = () => {
  const [activePrompt, setActivePrompt] = useState<string>('');
  const [customPrompt, setCustomPrompt] = useState<string>('');
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('preview');
  const { user } = useAuth();
  const { toast } = useToast();

  const handlePromptSelect = (prompt: string, language: string) => {
    setActivePrompt(prompt);
    setCustomPrompt('');
    setGeneratedCode('');
    generateWebsite(prompt);
  };

  const handleGenerateCode = async () => {
    if (!customPrompt.trim()) {
      toast({
        title: "Empty Prompt",
        description: "Please enter a prompt to generate your website",
        variant: "destructive",
      });
      return;
    }
    
    setActivePrompt(customPrompt);
    await generateWebsite(customPrompt);
  };

  const generateWebsite = async (prompt: string) => {
    setIsGenerating(true);
    setGeneratedCode('');
    setActiveTab('preview');
    
    try {
      console.log('Calling generate-website function with prompt:', prompt);
      
      const { data, error } = await supabase.functions.invoke('generate-website', {
        body: { prompt }
      });

      if (error) {
        console.error('Supabase function error:', error);
        throw error;
      }

      if (data?.code) {
        setGeneratedCode(data.code);
        toast({
          title: "Website Generated!",
          description: "Your website has been generated successfully. Check the preview tab.",
        });
      } else {
        throw new Error('No code generated');
      }
      
    } catch (error) {
      console.error("Error generating website:", error);
      toast({
        title: "Generation Failed",
        description: "Failed to generate website. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!generatedCode.trim()) return;
    
    const blob = new Blob([generatedCode], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'generated-website.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download Started",
      description: "Your website has been downloaded as an HTML file.",
    });
  };

  const handleSaveProject = async (projectName: string) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to save your websites",
        variant: "destructive",
      });
      return;
    }
    
    if (!activePrompt || !generatedCode.trim()) {
      toast({
        title: "Cannot Save",
        description: "Please generate a website first",
        variant: "destructive",
      });
      return;
    }
    
    try {
      await saveProject({
        user_id: user.id,
        name: projectName,
        html_content: generatedCode,
        prompt: activePrompt,
        is_template: false,
      });
      
      toast({
        title: "Project Saved",
        description: "Your website has been saved to your profile",
      });
    } catch (error) {
      console.error("Error saving project:", error);
      toast({
        title: "Error",
        description: "Failed to save project",
        variant: "destructive",
      });
    }
  };

  return {
    activePrompt,
    customPrompt,
    setCustomPrompt,
    generatedCode,
    isGenerating,
    activeTab,
    setActiveTab,
    handlePromptSelect,
    handleGenerateCode,
    handleDownload,
    handleSaveProject,
  };
};
