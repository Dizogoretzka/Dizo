
// Define the database schema types for TypeScript
export interface Database {
  public: {
    Tables: {
      courses: {
        Row: {
          id: string;
          title: string;
          description: string;
          category: string;
          image_url: string;
          level: 'beginner' | 'intermediate' | 'advanced';
        };
        Insert: {
          id?: string;
          title: string;
          description: string;
          category: string;
          image_url: string;
          level: 'beginner' | 'intermediate' | 'advanced';
        };
        Update: {
          id?: string;
          title?: string;
          description?: string;
          category?: string;
          image_url?: string;
          level?: 'beginner' | 'intermediate' | 'advanced';
        };
      };
      lessons: {
        Row: {
          id: string;
          course_id: string;
          title: string;
          order: number;
          content: string;
          estimated_time: number;
        };
        Insert: {
          id?: string;
          course_id: string;
          title: string;
          order: number;
          content: string;
          estimated_time: number;
        };
        Update: {
          id?: string;
          course_id?: string;
          title?: string;
          order?: number;
          content?: string;
          estimated_time?: number;
        };
      };
      progress: {
        Row: {
          id: string;
          user_id: string;
          lesson_id: string;
          completed: boolean;
          completed_at?: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          lesson_id: string;
          completed: boolean;
          completed_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          lesson_id?: string;
          completed?: boolean;
          completed_at?: string;
        };
      };
      code_snippets: {
        Row: {
          id: string;
          created_at: string;
          prompt: string;
          code: string;
          language: string;
          user_id: string;
        };
        Insert: {
          id?: string;
          created_at?: string;
          prompt: string;
          code: string;
          language: string;
          user_id: string;
        };
        Update: {
          id?: string;
          created_at?: string;
          prompt?: string;
          code?: string;
          language?: string;
          user_id?: string;
        };
      };
    };
    Views: {};
    Functions: {};
    Enums: {};
  };
}
