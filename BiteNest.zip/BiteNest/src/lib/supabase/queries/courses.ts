
import { supabase } from '../client';
import { Database } from '@/types/database';

export type Course = {
  id: string;
  title: string;
  description: string;
  category: string;
  image_url: string;
  level: 'beginner' | 'intermediate' | 'advanced';
};

// Fix typing issues by using proper type assertions
export const getCourses = async (category: string) => {
  const { data, error } = await supabase
    .from('courses')
    .select('*')
    .eq('category', category);

  if (error) {
    throw error;
  }

  return data as Course[];
};

export const getCourse = async (courseId: string) => {
  const { data, error } = await supabase
    .from('courses')
    .select('*')
    .eq('id', courseId)
    .single();

  if (error) {
    throw error;
  }

  return data as Course;
};
