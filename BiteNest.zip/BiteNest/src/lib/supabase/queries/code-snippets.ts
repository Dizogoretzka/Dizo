
import { supabase } from '../client';
import { Database } from '@/types/database';

export type CodeSnippet = {
  id: string;
  created_at: string;
  prompt: string;
  code: string;
  language: string;
  user_id: string;
};

// Fix typing issues by using proper type assertions
export const getCodeSnippets = async (userId: string) => {
  const { data, error } = await supabase
    .from('code_snippets')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    throw error;
  }

  return data as CodeSnippet[];
};

export const saveCodeSnippet = async (snippet: Omit<CodeSnippet, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('code_snippets')
    .insert(snippet);

  if (error) {
    throw error;
  }

  return data;
};
