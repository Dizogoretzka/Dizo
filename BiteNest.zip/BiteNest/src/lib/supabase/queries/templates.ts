
import { supabase } from '../client';

export type Template = {
  id: string;
  name: string;
  description?: string;
  category: string;
  html_content: string;
  css_content?: string;
  js_content?: string;
  preview_image_url?: string;
  is_featured: boolean;
  created_at: string;
};

export const getTemplates = async (category?: string) => {
  let query = supabase
    .from('templates')
    .select('*')
    .order('is_featured', { ascending: false })
    .order('created_at', { ascending: false });

  if (category) {
    query = query.eq('category', category);
  }

  const { data, error } = await query;

  if (error) {
    throw error;
  }

  return data as Template[];
};

export const getTemplate = async (templateId: string) => {
  const { data, error } = await supabase
    .from('templates')
    .select('*')
    .eq('id', templateId)
    .single();

  if (error) {
    throw error;
  }

  return data as Template;
};

export const getFeaturedTemplates = async () => {
  const { data, error } = await supabase
    .from('templates')
    .select('*')
    .eq('is_featured', true)
    .order('created_at', { ascending: false });

  if (error) {
    throw error;
  }

  return data as Template[];
};
