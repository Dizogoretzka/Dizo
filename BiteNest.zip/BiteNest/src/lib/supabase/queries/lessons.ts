
import { supabase } from '../client';
import { Database } from '@/types/database';

export type Lesson = {
  id: string;
  course_id: string;
  title: string;
  order: number;
  content: string;
  estimated_time: number;
};

export const getLessons = async (courseId: string) => {
  const { data, error } = await supabase
    .from('lessons')
    .select('*')
    .eq('course_id', courseId)
    .order('order', { ascending: true });

  if (error) {
    throw error;
  }

  return data as Lesson[];
};

export const getLesson = async (lessonId: string) => {
  const { data, error } = await supabase
    .from('lessons')
    .select('*')
    .eq('id', lessonId)
    .single();

  if (error) {
    throw error;
  }

  return data as Lesson;
};
