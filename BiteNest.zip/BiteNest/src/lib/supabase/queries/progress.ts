
import { supabase } from '../client';
import { Database } from '@/types/database';

export type Progress = {
  id: string;
  user_id: string;
  lesson_id: string;
  completed: boolean;
  completed_at?: string;
};

export const markLessonAsCompleted = async (userId: string, lessonId: string) => {
  const { error } = await supabase
    .from('progress')
    .insert({
      user_id: userId,
      lesson_id: lessonId,
      completed: true
    });

  if (error) {
    throw error;
  }
};

export const getUserProgress = async (userId: string) => {
  const { data, error } = await supabase
    .from('progress')
    .select('*')
    .eq('user_id', userId);

  if (error) {
    throw error;
  }

  return data as Progress[];
};
