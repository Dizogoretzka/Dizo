
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

// Use our constant values for the project URL and anon key
const supabaseUrl = 'https://gleafaxzmgsldicqlgop.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdsZWFmYXh6bWdzbGRpY3FsZ29wIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU2OTg2MzYsImV4cCI6MjA2MTI3NDYzNn0.97G5K33w-wkhrnz8-QxtDJ0LP4rpVjqSSFT7Woq506A';

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storage: localStorage,
  },
});
