
// Re-export types
export * from '@/types/database';

// Export client
export { supabase } from './client';

// Re-export query functions and types
export { getCourses, getCourse, type Course } from './queries/courses';
export { getLessons, getLesson, type Lesson } from './queries/lessons';
export { getUserProgress, markLessonAsCompleted, type Progress } from './queries/progress';
export { getCodeSnippets, saveCodeSnippet, type CodeSnippet } from './queries/code-snippets';
export { getUserProjects, getProject, saveProject, updateProject, deleteProject, type Project } from './queries/projects';
export { getTemplates, getTemplate, getFeaturedTemplates, type Template } from './queries/templates';
export { getProfile, updateProfile, createProfile, type Profile } from './queries/profiles';
