
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";

// Pages
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import Courses from "@/pages/Courses";
import CourseDetails from "@/pages/CourseDetails";
import LessonPage from "@/pages/LessonPage";
import CodeGenerator from "@/pages/CodeGenerator";
import Templates from "@/pages/Templates";
import MyProjects from "@/pages/MyProjects";
import Profile from "@/pages/Profile";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Navbar />
          <main className="min-h-[calc(100vh-4rem)]">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              
              {/* Public routes for courses */}
              <Route path="/courses/:category" element={<Courses />} />
              <Route path="/courses/:category/:courseId" element={<CourseDetails />} />
              <Route path="/courses/:category/:courseId/lessons/:lessonId" element={<LessonPage />} />
              
              {/* Public routes for code generator and templates */}
              <Route path="/code-generator" element={<CodeGenerator />} />
              <Route path="/templates" element={<Templates />} />
              
              {/* Protected routes */}
              <Route element={<ProtectedRoute />}>
                <Route path="/my-projects" element={<MyProjects />} />
                <Route path="/profile" element={<Profile />} />
              </Route>
              
              {/* Catch-all route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
